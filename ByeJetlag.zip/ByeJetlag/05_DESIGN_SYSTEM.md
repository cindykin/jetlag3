# 05_DESIGN_SYSTEM.md — ByeJetlag

> **Status:** Source of truth. Isi requirement utama berasal dari knowledge base yang sudah ada di archive project yang diaudit. Jangan mengubah kontrak di file ini sebagai efek samping task coding biasa.

> Baca `01_PRODUCT.md`, `04_ALGORITHM.md`, dan `02_ARCHITECTURE.md` dulu.
> File ini soal token visual & rendering timeline. Logic kapan sebuah block muncul/tidak overlap ada di `04_ALGORITHM.md` Section 3 — jangan duplikat logic di sini, cukup referensi.

---

## 1. Warna Primer
```
Primary: #C45500
```
Ini warna aksen utama app (tombol CTA, active state, dsb — bukan warna block).

## 2. Warna per Block Type

Tiap block punya 2 warna: warna aksen/ikon (foreground) dan warna background block-nya.

| Block Type | Foreground | Background |
|---|---|---|
| Seek Light | `#FFBE00` | `#FFF9EC` |
| Go to Sleep | `#1D57AF` | `#EDF3FC` |
| Take melantonin & Go to Sleep | `#1D57AF` | `#EDF3FC` |
| Take a nap (If can) | `#1D7DAF` | `#EEF7FC` |
| Caffeine | `#855216` | `#FCF5ED` |
| Avoid Light | `#808080` | `#F2F2F2` |
| Avoid Caffeine | `#808080` | `#F2F2F2` |
| Flight | `#111111` | `#F2F2F2` |

Jam berada di kolom kiri, sedangkan activity blocks berada di sisi kanan.
Setiap block punya warna latar lembut, garis indikator vertikal berwarna di sisi kiri, icon, judul, dan rentang waktu.



## 3. Ikon per Block Type
Semua icon menggunakan SF Symbols style fill. Jika ada 2 icon maka group mereka pake HStack
- Seek light = sun.max.fill
- sleep = bed.double.fill
- Melatonin = bed.double.fill + pill.fill
- nap = bed.double.fill + sun.max.fill
- caffeine = cup.and.saucer.fill
- avoid light = sun.max.fill + x.circle
- avoid caffeine = cup.and.saucer.fill + x.circle
- flight = airplane.up.right

## 4. Layout Timeline (Timeline System)

Rendering timeline WAJIB pakai pendekatan ini (bukan `List`/`ScrollView` dengan section biasa):

- Gunakan **`ZStack`** sebagai container utama timeline.
- **Map waktu → posisi Y**: setiap block di-posisikan secara vertikal berdasarkan waktu mulainya (fungsi konversi `time → yOffset`, linear terhadap rentang jam yang ditampilkan).
- **Height block = durasi.** Block yang durasinya lebih lama (misal Sleep 8 jam) harus terlihat lebih tinggi/panjang secara visual dibanding block singkat (misal Caffeine cutoff instan/singkat).
- **Prevent visual overlap** — dua block tidak boleh render bertumpuk secara visual di posisi Y yang sama. Ini konsisten dengan Aturan Non-Overlap di `04_ALGORITHM.md` Section 3.C (Sleep menang mutlak, dst) — logic di situ menentukan block MANA yang boleh ada, layout ini menentukan CARA render-nya di posisi yang benar tanpa tabrakan visual.

## 5. Timezone Divider (Visual)
- Divider berupa garis horizontal pemisah di timeline.
- Muncul dengan badge teks **"Arrival city time"** khusus saat kondisi "flight arrival di timezone baru" (logic kapan muncul: lihat `04_ALGORITHM.md` Section 9).
- Untuk kondisi "tengah malam lokal", perlu dikonfirmasi apakah badge-nya beda teks (misal cuma tanggal baru, tanpa teks "Arrival city time") — **belum ada contoh visualnya**.

## 6. Tipografi

-- Gunakan system font dengan skala `.largeTitle/.title/.headline/.body/.caption` bawaan iOS

## 7. Corner Radius
-- corner radius standar untuk block type di timeline 8px
-- corner radius untuk block flag dan trip 16px
---

## Yang Masih Perlu Dikonfirmasi / Dikirim Ulang
1. Warna & ikon **Melatonin** yang presisi.
2. Nama/sumber aset ikon untuk 7 block type lainnya (SF Symbols atau custom asset di `Assets.xcassets`).
3. Tipografi (font family, ukuran heading/body/caption) — belum ada info sama sekali soal ini, baik dari gambar maupun teks. Kalau tidak dikirim, defaultnya AI akan pakai SF Pro (system font) dengan skala `.largeTitle/.title/.headline/.body/.caption` bawaan iOS — konfirmasi kalau itu bukan yang dimaksud.
4. Spacing/corner radius standar untuk block card di timeline (dari gambar kelihatan rounded corner, tapi radius pastinya berapa px belum ada datanya).
